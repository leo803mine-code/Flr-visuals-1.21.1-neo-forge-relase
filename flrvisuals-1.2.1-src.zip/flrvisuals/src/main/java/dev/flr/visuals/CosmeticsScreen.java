package dev.flr.visuals;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * FLR Visuals cosmetics menu (NeoForge 1.21.1).
 * Rounded panels, pulsing accent glow, frame-time eased animations.
 */
public class CosmeticsScreen extends Screen {
    public static final String VERSION = "1.2.0";

    private static final String[] TABS = {"Cosmetics", "Effects", "Style", "Performance"};
    private static final String[] TAB_ICONS = {"✦", "◈", "◉", "⚙"};

    private static final int PANEL_W = 340;
    private static final int PANEL_H = 232;
    private static final int SIDEBAR = 96;
    private static final int PAD = 12;
    private static final int ROW_H = 22;
    private static final int TAB_H = 28;
    private static final int RADIUS = 10;
    private static final float ANIM_RATE = 12f;
    private static final float PULSE_HZ = 0.6f;

    private static final int TYPE_TOGGLE = 0, TYPE_SLIDER = 1, TYPE_CHOICE = 2, TYPE_BUTTON = 3;

    private static final int COL_BG = 0xE6101018;
    private static final int COL_SIDEBAR = 0x66000000;
    private static final int COL_TRACK = 0xFF2A2F3D;
    private static final int COL_TEXT = 0xFFE6E8F0;
    private static final int COL_MUTED = 0xFF8A90A6;

    private static final class Row {
        final String label;
        final int type;
        BooleanSupplier bget;
        Consumer<Boolean> bset;
        DoubleSupplier dget;
        DoubleConsumer dset;
        double min, max;
        DoubleFunction<String> dfmt;
        String[] opts;
        IntSupplier iget;
        IntConsumer iset;
        Runnable run;
        float anim;
        int y;

        Row(String label, int type) {
            this.label = label;
            this.type = type;
        }
    }

    private final List<List<Row>> pages = new ArrayList<>();
    private int tab;
    private int px, py;
    private float indicatorY;
    private Row dragging;
    private long lastFrame;
    private final long openedAt = System.nanoTime();

    public CosmeticsScreen() {
        super(Component.literal("FLR VISUALS"));
    }

    // ---------- row factories ----------

    private static Row toggle(String label, BooleanSupplier g, Consumer<Boolean> s) {
        Row r = new Row(label, TYPE_TOGGLE);
        r.bget = g;
        r.bset = s;
        return r;
    }

    private static Row slider(String label, double min, double max, DoubleSupplier g,
                              DoubleConsumer s, DoubleFunction<String> fmt) {
        Row r = new Row(label, TYPE_SLIDER);
        r.min = min;
        r.max = max;
        r.dget = g;
        r.dset = s;
        r.dfmt = fmt;
        return r;
    }

    private static Row choice(String label, String[] opts, IntSupplier g, IntConsumer s) {
        Row r = new Row(label, TYPE_CHOICE);
        r.opts = opts;
        r.iget = g;
        r.iset = s;
        return r;
    }

    private static Row button(String label, Runnable run) {
        Row r = new Row(label, TYPE_BUTTON);
        r.run = run;
        return r;
    }

    private static String twoDec(double v) {
        return String.format("%.2f", v);
    }

    @Override
    protected void init() {
        pages.clear();

        pages.add(List.of(
                toggle("Halo", () -> Config.halo, v -> Config.halo = v),
                toggle("Wings", () -> Config.wings, v -> Config.wings = v),
                toggle("Cape", () -> Config.cape, v -> Config.cape = v),
                choice("Wing style", Config.WING_NAMES, () -> Config.wingStyle, v -> Config.wingStyle = v),
                slider("Wing size", 0.6, 1.8, () -> Config.wingSize, v -> Config.wingSize = v, CosmeticsScreen::twoDec),
                slider("Effect scale", 0.6, 1.6, () -> Config.scale, v -> Config.scale = v, CosmeticsScreen::twoDec),
                toggle("Show on other players", () -> Config.others, v -> Config.others = v)
        ));

        pages.add(List.of(
                toggle("Particles", () -> Config.particles, v -> Config.particles = v),
                toggle("Aura", () -> Config.aura, v -> Config.aura = v),
                toggle("Trail", () -> Config.trail, v -> Config.trail = v),
                toggle("Hit sparks", () -> Config.hitSparks, v -> Config.hitSparks = v),
                toggle("Ambient fireflies", () -> Config.ambient, v -> Config.ambient = v),
                choice("Particle style", Config.PARTICLE_NAMES, () -> Config.particleType, v -> Config.particleType = v),
                slider("Fog tint", 0.0, 1.0, () -> Config.fogTint, v -> Config.fogTint = v, CosmeticsScreen::twoDec),
                slider("Fog density", 0.0, 1.0, () -> Config.fogDensity, v -> Config.fogDensity = v, CosmeticsScreen::twoDec)
        ));

        pages.add(List.of(
                choice("Theme", Config.THEME_NAMES, () -> Config.theme, v -> Config.theme = v),
                slider("Custom hue", 0.0, 360.0, () -> Config.hue, v -> Config.hue = v, v -> String.format("%.0f°", v)),
                slider("Animation speed", 0.2, 3.0, () -> Config.speed, v -> Config.speed = v, CosmeticsScreen::twoDec)
        ));

        pages.add(List.of(
                toggle("Auto performance", () -> Config.autoPerf, v -> Config.autoPerf = v),
                slider("Particle budget", 10, 300, () -> Config.particleBudget,
                        v -> Config.particleBudget = (int) Math.round(v), v -> String.format("%.0f", v)),
                slider("Max distance", 16, 256, () -> Config.maxDistance, v -> Config.maxDistance = v,
                        v -> String.format("%.0f", v)),
                toggle("HUD badge", () -> Config.hud, v -> Config.hud = v),
                button("Preset: Minimal", () -> Config.preset(0)),
                button("Preset: Balanced", () -> Config.preset(1)),
                button("Preset: Max", () -> Config.preset(2)),
                button("Reset to defaults", Config::reset)
        ));

        px = (width - PANEL_W) / 2;
        py = (height - PANEL_H) / 2;
        indicatorY = tabY(tab);
        layoutRows();
    }

    // ---------- layout ----------

    private int contentX() { return px + SIDEBAR + PAD; }
    private int contentW() { return PANEL_W - SIDEBAR - PAD * 2; }
    private float tabY(int i) { return py + 46 + i * TAB_H; }

    private void layoutRows() {
        List<Row> rows = pages.get(tab);
        for (int i = 0; i < rows.size(); i++) {
            rows.get(i).y = py + 34 + i * ROW_H;
        }
    }

    private boolean inRow(Row r, double mx, double my) {
        return mx >= contentX() - 4 && mx <= contentX() + contentW() + 4
                && my >= r.y && my < r.y + ROW_H - 2;
    }

    // ---------- color helpers ----------

    private static int withAlpha(int argb, int a) {
        return (Mth.clamp(a, 0, 255) << 24) | (argb & 0xFFFFFF);
    }

    private static int blend(int a, int b, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = Math.round(ar + (br - ar) * t);
        int g = Math.round(ag + (bg - ag) * t);
        int bl = Math.round(ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ---------- rounded shapes (GuiGraphics has no rounded fill in 1.21.1) ----------

    /** Fills a rounded rectangle using horizontal scanlines with a circular corner profile. */
    private static void roundRect(GuiGraphics g, int x1, int y1, int x2, int y2, int radius, int color) {
        int w = x2 - x1;
        int h = y2 - y1;
        if (w <= 0 || h <= 0) return;
        int r = Math.max(0, Math.min(radius, Math.min(w, h) / 2));
        for (int y = y1; y < y2; y++) {
            int fromEdge = Math.min(y - y1, y2 - 1 - y);
            int inset = 0;
            if (fromEdge < r) {
                double dc = r - (fromEdge + 0.5);
                inset = r - (int) Math.round(Math.sqrt(Math.max(0.0, r * (double) r - dc * dc)));
            }
            g.fill(x1 + inset, y, x2 - inset, y + 1, color);
        }
    }

    /** Soft glow: a few expanding rounded layers with falling alpha. */
    private static void glow(GuiGraphics g, int x1, int y1, int x2, int y2, int radius, int color, int alpha, int layers) {
        for (int i = layers; i >= 1; i--) {
            int grow = i * 2;
            int a = alpha / (i + 1);
            roundRect(g, x1 - grow, y1 - grow, x2 + grow, y2 + grow, radius + grow, withAlpha(color, a));
        }
    }

    // ---------- rendering ----------

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = System.nanoTime();
        float dt = lastFrame == 0 ? 0f : Math.min(0.1f, (now - lastFrame) / 1_000_000_000f);
        lastFrame = now;
        float k = 1f - (float) Math.exp(-ANIM_RATE * (float) Config.speed * dt);
        float t = (now - openedAt) / 1_000_000_000f;
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * Math.PI * 2 * PULSE_HZ); // 0..1 breathing

        renderBackground(g, mouseX, mouseY, partialTick); // single blurred pass per frame

        px = (width - PANEL_W) / 2;
        py = (height - PANEL_H) / 2;
        layoutRows();

        int accent = Config.color() | 0xFF000000;
        int muted = COL_MUTED;

        // breathing glow around the panel
        glow(g, px, py, px + PANEL_W, py + PANEL_H, RADIUS, accent, (int) (40 + 50 * pulse), 3);

        // panel, border ring and sidebar
        roundRect(g, px - 1, py - 1, px + PANEL_W + 1, py + PANEL_H + 1, RADIUS + 1,
                withAlpha(accent, (int) (120 + 80 * pulse)));
        roundRect(g, px, py, px + PANEL_W, py + PANEL_H, RADIUS, COL_BG);
        roundRect(g, px + 6, py + 6, px + SIDEBAR - 2, py + PANEL_H - 6, 8, COL_SIDEBAR);

        // header
        g.drawString(font, "FLR", px + PAD, py + 12, accent, false);
        g.drawString(font, "VISUALS", px + PAD + 28, py + 12, 0xFFFFFFFF, false);
        g.drawString(font, "v" + VERSION, px + PAD, py + 24, muted, false);

        // eased tab indicator (pill)
        indicatorY += (tabY(tab) - indicatorY) * k;
        int iy = Math.round(indicatorY);
        roundRect(g, px + 10, iy, px + SIDEBAR - 8, iy + TAB_H - 4, 7, withAlpha(accent, 0x38));
        for (int i = 0; i < TABS.length; i++) {
            int ty = Math.round(tabY(i));
            g.drawString(font, TAB_ICONS[i] + "  " + TABS[i], px + PAD + 2, ty + 9,
                    i == tab ? 0xFFFFFFFF : muted, false);
        }

        // content header + pulsing status dot
        int cx = contentX();
        int cw = contentW();
        g.drawString(font, TABS[tab], cx, py + 14, 0xFFFFFFFF, false);
        String status = Config.master ? "ACTIVE" : "OFF";
        int statusW = font.width(status);
        int dotCol = Config.master ? withAlpha(accent, (int) (150 + 105 * pulse)) : muted;
        int sx = cx + cw - statusW - 14;
        roundRect(g, sx, py + 15, sx + 6, py + 21, 3, dotCol);
        g.drawString(font, status, cx + cw - statusW, py + 14, Config.master ? accent : muted, false);

        // rows
        for (Row r : pages.get(tab)) {
            boolean hovered = inRow(r, mouseX, mouseY);
            if (hovered) {
                roundRect(g, cx - 4, r.y, cx + cw + 4, r.y + ROW_H - 2, 6, 0x18FFFFFF);
            }
            g.drawString(font, r.label, cx, r.y + 7, COL_TEXT, false);
            switch (r.type) {
                case TYPE_TOGGLE -> drawToggle(g, r, cx, cw, accent, k);
                case TYPE_SLIDER -> drawSlider(g, r, cx, cw, accent, k);
                case TYPE_CHOICE -> drawChoice(g, r, cx, cw, accent);
                case TYPE_BUTTON -> drawButton(g, r, cx, cw, accent, hovered);
                default -> { }
            }
        }
    }

    private void drawToggle(GuiGraphics g, Row r, int cx, int cw, int accent, float k) {
        float target = r.bget.getAsBoolean() ? 1f : 0f;
        r.anim += (target - r.anim) * k;
        if (Math.abs(target - r.anim) < 0.005f) r.anim = target;

        int tx = cx + cw - 34;
        int ty = r.y + 4;
        roundRect(g, tx, ty, tx + 34, ty + 14, 7, blend(COL_TRACK, accent, r.anim));
        int knobX = tx + 2 + Math.round(r.anim * 20);
        roundRect(g, knobX, ty + 2, knobX + 10, ty + 12, 5, 0xFFFFFFFF);
    }

    private void drawSlider(GuiGraphics g, Row r, int cx, int cw, int accent, float k) {
        double v = r.dget.getAsDouble();
        float target = Mth.clamp((float) ((v - r.min) / (r.max - r.min)), 0f, 1f);
        r.anim += (target - r.anim) * k;
        if (Math.abs(target - r.anim) < 0.002f) r.anim = target;

        int tx = cx + cw - 110;
        int tw = 66;
        int ty = r.y + 9;
        roundRect(g, tx, ty, tx + tw, ty + 4, 2, COL_TRACK);
        int fillW = Math.max(4, Math.round(tw * r.anim));
        roundRect(g, tx, ty, tx + fillW, ty + 4, 2, accent);
        int knob = tx + Math.round(tw * r.anim);
        roundRect(g, knob - 3, ty - 3, knob + 3, ty + 7, 3, 0xFFFFFFFF);
        g.drawString(font, r.dfmt.apply(v), cx + cw - 36, r.y + 7, 0xFFC8CCD8, false);
    }

    private void drawChoice(GuiGraphics g, Row r, int cx, int cw, int accent) {
        int idx = Math.floorMod(r.iget.getAsInt(), r.opts.length);
        String text = r.opts[idx];
        int tw = font.width(text) + 16;
        int right = cx + cw;
        roundRect(g, right - tw, r.y + 3, right, r.y + ROW_H - 5, 6, withAlpha(accent, 0x2A));
        g.drawCenteredString(font, text, right - tw / 2, r.y + 7, accent);
    }

    private void drawButton(GuiGraphics g, Row r, int cx, int cw, int accent, boolean hovered) {
        int col = hovered ? accent : withAlpha(accent, 0xB0);
        roundRect(g, cx + cw - 22, r.y + 3, cx + cw, r.y + ROW_H - 5, 6, withAlpha(accent, hovered ? 0x44 : 0x22));
        g.drawCenteredString(font, "›", cx + cw - 11, r.y + 7, col);
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);

        for (int i = 0; i < TABS.length; i++) {
            int ty = Math.round(tabY(i));
            if (mx >= px + 10 && mx <= px + SIDEBAR - 8 && my >= ty && my <= ty + TAB_H - 4) {
                if (tab != i) {
                    tab = i;
                    layoutRows();
                }
                return true;
            }
        }

        for (Row r : pages.get(tab)) {
            if (!inRow(r, mx, my)) continue;
            switch (r.type) {
                case TYPE_TOGGLE -> {
                    r.bset.accept(!r.bget.getAsBoolean());
                    Config.save();
                }
                case TYPE_SLIDER -> {
                    dragging = r;
                    applySlider(r, mx);
                }
                case TYPE_CHOICE -> {
                    int n = r.opts.length;
                    r.iset.accept((Math.floorMod(r.iget.getAsInt(), n) + 1) % n);
                    Config.save();
                }
                case TYPE_BUTTON -> {
                    r.run.run();
                    Config.save();
                }
                default -> { }
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null && button == 0) {
            applySlider(dragging, mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    private void applySlider(Row r, double mx) {
        int tx = contentX() + contentW() - 110;
        float t = Mth.clamp((float) ((mx - tx) / 66.0), 0f, 1f);
        r.dset.accept(r.min + t * (r.max - r.min));
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
